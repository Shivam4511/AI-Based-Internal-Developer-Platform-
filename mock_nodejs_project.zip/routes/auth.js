const express = require('express');
const router = express.router();

router.post('/login', (req, res) => {
  const { username, password } = req.body;
  if (username === 'admin' && password === 'password') {
    return res.json({ token: 'mock-jwt-token-123' });
  }
  res.status(401).json({ error: 'Invalid credentials' });
});

module.exports = router;
