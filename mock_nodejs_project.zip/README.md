# Mock Express API

This is a sample project generated to test the IDP Platform upload feature.
It contains a simple Express server with a mock auth route.

## Usage
1. Upload this codebase.
2. Ask the AI to "Add a registration route" or "explain the auth flow".
